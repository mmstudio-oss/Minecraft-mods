$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host "=== Blocky Javelin: Forge 1.20.1 builder ===" -ForegroundColor Cyan
& java -version
if ($LASTEXITCODE -ne 0) { throw 'Java 17 JDK is required; java was not found.' }
$ver = '8.8'
$tools = Join-Path $PSScriptRoot '.gradle-tools'
$gradle = Join-Path $tools "gradle-$ver/bin/gradle.bat"
if (!(Test-Path $gradle)) {
    New-Item -ItemType Directory -Force -Path $tools | Out-Null
    $zip = Join-Path $tools "gradle-$ver-bin.zip"
    Write-Host "Downloading official Gradle $ver ..."
    Invoke-WebRequest -Uri "https://services.gradle.org/distributions/gradle-$ver-bin.zip" -OutFile $zip
    Expand-Archive -LiteralPath $zip -DestinationPath $tools -Force
    Remove-Item $zip
}
Write-Host 'Building mod (internet is required for Forge dependencies)...' -ForegroundColor Yellow
& $gradle build --no-daemon
if ($LASTEXITCODE -ne 0) { throw 'Gradle build failed. See the messages above.' }
Write-Host "SUCCESS! Find your mod at: $PSScriptRoot\build\libs\javelin-1.1.0.jar" -ForegroundColor Green
