"""Offline checks of the mod assets; does not replace a Java/Forge compilation."""
from pathlib import Path
import json

root = Path(__file__).resolve().parent / 'src/main/resources'
assets = root / 'assets/javelin'
assert (root / 'META-INF/mods.toml').is_file()
assert (root / 'pack.mcmeta').is_file()
for lang in ('ru_ru', 'en_us'):
    labels = json.loads((assets / 'lang' / f'{lang}.json').read_text(encoding='utf-8'))
    for key in ('item.javelin.javelin_launcher', 'item.javelin.javelin_round',
                'hud.javelin.ready', 'hud.javelin.locking'):
        assert key in labels, (lang, key)
for model_name in ('javelin_launcher', 'javelin_round'):
    path = assets / 'models/item' / f'{model_name}.json'
    model = json.loads(path.read_text(encoding='utf-8'))
    assert len(model.get('elements', [])) >= 10
    textures = model['textures']
    for name, resource in textures.items():
        namespace, resource_path = resource.split(':', 1)
        assert namespace == 'javelin'
        assert (assets / 'textures' / (resource_path + '.png')).is_file(), (model_name, resource)
    for element in model['elements']:
        assert all(-16 <= n <= 32 for n in element['from'] + element['to'])
        assert all(lo < hi for lo, hi in zip(element['from'], element['to']))
        for face in element['faces'].values():
            assert face['texture'].removeprefix('#') in textures
for recipe in (root / 'data/javelin/recipes').glob('*.json'):
    json.loads(recipe.read_text(encoding='utf-8'))
print('OK: item models, textures, recipes, mod metadata and translations')
