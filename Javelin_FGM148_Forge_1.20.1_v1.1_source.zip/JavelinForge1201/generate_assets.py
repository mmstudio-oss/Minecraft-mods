"""Generates original, editable Minecraft-style texture and block-model JSON assets.
Requires Pillow to regenerate textures; generated assets are already included.
"""
from pathlib import Path
import json, random
from PIL import Image, ImageDraw

ROOT = Path(__file__).parent / 'src/main/resources/assets/javelin'
TEX = ROOT / 'textures/item'
MODELS = ROOT / 'models/item'
TEX.mkdir(parents=True, exist_ok=True)
MODELS.mkdir(parents=True, exist_ok=True)

palettes = {
  'olive': [(64,78,51),(69,86,57),(80,93,63),(57,75,46),(77,86,54)],
  'olive_light':[(91,109,67),(97,111,73),(82,103,61),(103,119,78)],
  'olive_dark':[(44,58,36),(39,51,34),(50,62,44),(58,65,42)],
  'black': [(21,25,27),(30,33,36),(39,42,42),(17,20,22)],
  'rubber':[(40,43,41),(48,48,46),(36,38,35),(58,60,58)],
  'steel':[(178,181,172),(189,190,185),(155,158,151),(204,204,197)],
  'steel_dark':[(91,94,92),(109,112,106),(126,128,120),(80,86,84)],
  'gold':[(200,150,41),(241,185,50),(173,123,28),(220,174,45)],
  'copper':[(177,117,65),(193,138,78),(147,92,54)],
  'warhead':[(27,28,28),(34,35,34),(42,42,41)],
  'optic':[(17,42,42),(16,79,73),(26,122,107),(18,58,64),(29,157,141)],
}
for pidx,(name,colors) in enumerate(palettes.items()):
    rng=random.Random(610+pidx)
    img=Image.new('RGBA',(16,16))
    px=img.load()
    for y in range(16):
        for x in range(16):
            idx=(x//3+2*(y//4)+rng.randrange(len(colors)))%len(colors)
            px[x,y]=(*colors[idx],255)
    if name=='optic':
        d=ImageDraw.Draw(img)
        d.rectangle((0,0,15,15),outline=(15,25,24))
        d.ellipse((2,2,13,13),fill=(20,102,103),outline=(38,191,171),width=2)
        d.ellipse((5,5,10,10),fill=(13,29,44),outline=(34,133,121))
        d.point((5,4),fill=(159,250,230))
    elif name in ('olive','steel'):
        d=ImageDraw.Draw(img)
        for y in (3,10):
            d.line((0,y,15,y),fill=(*colors[0],255))
    img.save(TEX / f'{name}.png')

faces = ('north','south','east','west','up','down')

def cube(a,b,tex,faces_by_dir=None):
    f={direction:{'texture':f'#{(faces_by_dir or {}).get(direction,tex)}'} for direction in faces}
    return {'from':list(a),'to':list(b),'faces':f}

launcher = [
    cube((4.5,8.5,0),(11.5,15.5,16),'olive'),
    cube((5,9,0),(11,15,16),'olive_light'),
    # The launcher muzzle, interior, retaining lock ring.
    cube((4,8,0),(12,16,0.85),'olive_dark'),
    cube((4.6,8.6,-0.15),(11.4,15.4,0.12),'gold'),
    cube((5.4,9.4,-0.22),(10.6,14.6,-0.12),'black'),
    cube((6.0,10.1,-0.23),(9.9,13.8,-0.20),'rubber'),
    cube((4.0,8.0,15.2),(12,16,16),'rubber'),
    # Pixel-art black command and sight package on the side.
    cube((10.5,8.1,3.7),(15.2,12.8,10.9),'black'),
    cube((11,10.0,4.5),(14.5,14.2,9.7),'rubber'),
    cube((14.8,9.2,4.5),(15.9,11.8,7.1),'optic'),
    cube((14.8,9.2,8.0),(15.9,11.8,10.2),'optic'),
    cube((11.3,12.5,5.1),(15.5,13.5,8.3),'black'),
    cube((11.6,13.6,5.5),(15,15.0,7.8),'rubber'),
    # Front grip and handguard, subtle clasps.
    cube((7.0,4.0,9.1),(9.5,8.7,11.6),'black'),
    cube((6.8,3.2,9.7),(9.8,4.1,12),'rubber'),
    cube((5.5,7,6.3),(11.3,9.2,12.5),'black'),
    cube((4,9.2,5.2),(4.6,14.6,6),'steel_dark'),
    cube((11.5,9.4,5.2),(11.95,14.6,6),'gold'),
    cube((4.6,8.7,12.1),(11.5,9.6,13.1),'olive_dark'),
]

rocket = [
    cube((6.2,6.2,0.0),(9.8,9.8,1.0),'warhead'),
    cube((5.5,5.5,1),(10.5,10.5,2.4),'warhead'),
    cube((5,5,2.4),(11,11,13.7),'steel'),
    cube((4.8,4.8,2.35),(11.2,11.2,2.9),'copper'),
    cube((4.93,4.93,6.8),(11.07,11.07,8),'black'),
    cube((4.93,4.93,12.4),(11.07,11.07,13.8),'black'),
    cube((5.2,5.2,13.8),(10.8,10.8,15.7),'warhead'),
    cube((5.8,5.8,15.7),(10.2,10.2,16),'steel_dark'),
    # Block-shaped fins around tail, like in the reference.
    cube((1,7.3,12.6),(5.1,8.7,14.7),'warhead'),
    cube((10.9,7.3,12.6),(15,8.7,14.7),'warhead'),
    cube((7.3,1,12.6),(8.7,5.1,14.7),'warhead'),
    cube((7.3,10.9,12.6),(8.7,15,14.7),'warhead'),
    # Four smaller guidance vanes along the airframe.
    cube((3.1,7.5,9),(5.3,8.5,10.4),'steel_dark'),
    cube((10.7,7.5,9),(12.9,8.5,10.4),'steel_dark'),
    cube((7.5,3.1,9),(8.5,5.3,10.4),'steel_dark'),
    cube((7.5,10.7,9),(8.5,12.9,10.4),'steel_dark'),
]

def save(name,els,display):
    model={
        'credit':'Original 3D pixel model for Javelin Forge mod',
        'texture_size':[16,16],
        'textures':{n:f'javelin:item/{n}' for n in palettes},
        'elements':els,
        'display':display,
    }
    (MODELS / (name+'.json')).write_text(json.dumps(model,indent=2,ensure_ascii=False),encoding='utf-8')

save('javelin_launcher',launcher,{
    'gui':{'rotation':[28,45,0],'translation':[0,0,0],'scale':[1,1,1]},
    'ground':{'rotation':[0,0,0],'translation':[0,3,0],'scale':[.7,.7,.7]},
    'fixed':{'rotation':[0,180,0],'translation':[0,0,0],'scale':[.85,.85,.85]},
    'thirdperson_righthand':{'rotation':[5,-80,65],'translation':[0,3,-1],'scale':[1.4,1.4,1.4]},
    'thirdperson_lefthand':{'rotation':[5,80,-65],'translation':[0,3,-1],'scale':[1.4,1.4,1.4]},
    'firstperson_righthand':{'rotation':[3,-95,38],'translation':[2,2,1],'scale':[1.8,1.8,1.8]},
    'firstperson_lefthand':{'rotation':[3,95,-38],'translation':[-2,2,1],'scale':[1.8,1.8,1.8]},
})
save('javelin_round',rocket,{
    'gui':{'rotation':[20,140,10],'translation':[0,0,0],'scale':[1,1,1]},
    'ground':{'rotation':[0,0,0],'translation':[0,2,0],'scale':[.7,.7,.7]},
    'fixed':{'rotation':[0,0,0],'translation':[0,0,0],'scale':[1,1,1]},
    'firstperson_righthand':{'rotation':[0,65,0],'translation':[0,2,0],'scale':[.85,.85,.85]},
    'thirdperson_righthand':{'rotation':[0,65,0],'translation':[0,2,0],'scale':[.8,.8,.8]},
})
print('Created', len(palettes), 'textures and 2 detailed model JSON files')
