package com.example.javelin.gameplay;

import com.example.javelin.JavelinMod;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Short, staged, Minecraft-styled cinematic explosion. Unlike a single emitter,
 * each blast animates for over a second even on a dedicated Forge server.
 * Uses only built-in particle types: no client-only classes are touched here.
 */
@Mod.EventBusSubscriber(modid = JavelinMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ExplosionEffects {
    private static final Map<ServerLevel, List<Blast>> ACTIVE = new WeakHashMap<>();
    private static final int LIFETIME = 28;

    public static void spawn(ServerLevel level, Vec3 point) {
        // The vanilla explosion handles damage/sound; this handles extra visuals.
        ACTIVE.computeIfAbsent(level, unused -> new ArrayList<>()).add(new Blast(point));
        particles(level, ParticleTypes.EXPLOSION_EMITTER, point, 1, 0, 0, 0, 0);
        particles(level, ParticleTypes.FLAME, point.add(0, 0.2D, 0), 85, 1.1D, 0.6D, 1.1D, 0.15D);
        particles(level, ParticleTypes.CLOUD, point, 85, 1.2D, 0.35D, 1.2D, 0.28D);
        particles(level, ParticleTypes.LAVA, point, 15, 0.75D, 0.65D, 0.75D, 0.09D);
    }

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.level instanceof ServerLevel level)) return;
        List<Blast> blasts = ACTIVE.get(level);
        if (blasts == null) return;
        Iterator<Blast> it = blasts.iterator();
        while (it.hasNext()) {
            Blast blast = it.next();
            blast.update(level);
            if (blast.age >= LIFETIME) it.remove();
        }
        if (blasts.isEmpty()) ACTIVE.remove(level);
    }

    private static void particles(ServerLevel world, ParticleOptions type, Vec3 p,
                                  int count, double dx, double dy, double dz, double speed) {
        world.sendParticles(type, p.x, p.y, p.z, count, dx, dy, dz, speed);
    }

    private static final class Blast {
        private final Vec3 at;
        private int age;

        private Blast(Vec3 position) {
            this.at = position;
        }

        private void update(ServerLevel world) {
            age++;
            // Expanding ground-level shock ring: clearly readable even from afar.
            if (age <= 9) {
                double radius = 0.9D + age * 0.68D;
                for (int i = 0; i < 22; i++) {
                    double angle = i * Math.PI * 2.0D / 22.0D + age * 0.07D;
                    Vec3 p = at.add(Math.cos(angle) * radius, 0.15D + (age % 3) * 0.12D,
                            Math.sin(angle) * radius);
                    particles(world, ParticleTypes.CLOUD, p, 1, 0.08D, 0.05D, 0.08D, 0.01D);
                }
            }

            // Dense rising smoke column followed by slower drifting soot.
            if (age <= 23) {
                double t = age / (double) LIFETIME;
                double spread = 0.5D + t * 2.1D;
                Vec3 top = at.add(0, 0.25D + age * 0.23D, 0);
                particles(world, ParticleTypes.LARGE_SMOKE, top, age < 11 ? 19 : 9,
                        spread, 0.35D, spread, 0.035D);
                if (age % 2 == 0) {
                    particles(world, ParticleTypes.CAMPFIRE_COSY_SMOKE, top, 5,
                            spread * 0.7D, 0.35D, spread * 0.7D, 0.025D);
                }
                if (age < 12) {
                    particles(world, ParticleTypes.FLAME, at.add(0, 0.35D + age * 0.06D, 0),
                            14, 1.1D, 0.45D, 1.1D, 0.02D);
                }
            }
            if (age == 3 || age == 7) {
                particles(world, ParticleTypes.EXPLOSION, at.add(0, age * 0.2D, 0),
                        7, 0.9D, 0.45D, 0.9D, 0.01D);
            }
        }
    }

    private ExplosionEffects() {}
}
