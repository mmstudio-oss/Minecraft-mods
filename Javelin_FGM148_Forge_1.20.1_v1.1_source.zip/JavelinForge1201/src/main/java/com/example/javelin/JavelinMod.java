package com.example.javelin;

import com.example.javelin.config.JavelinConfig;
import com.example.javelin.network.ModNetwork;
import com.example.javelin.registry.ModEntities;
import com.example.javelin.registry.ModItems;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraft.world.item.CreativeModeTabs;

@Mod(JavelinMod.MOD_ID)
public class JavelinMod {
    public static final String MOD_ID = "javelin";

    public JavelinMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        bus.addListener(this::onBuildCreativeTab);
        ModNetwork.init();
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, JavelinConfig.SPEC);
    }

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MOD_ID, path);
    }

    private void onBuildCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(ModItems.LAUNCHER);
            event.accept(ModItems.ROUND);
        }
    }
}
