package com.example.javelin.gameplay;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Ray cast is performed again on the server, never trusting a target supplied by a client. */
public final class Targeting {
    public static final double MAX_RANGE = 192.0D;

    public record Target(Vec3 position, LivingEntity living) {
        public boolean hasEntity() { return living != null; }
    }

    public static Target acquire(Level level, Player player) {
        Vec3 origin = player.getEyePosition();
        Vec3 last = origin.add(player.getLookAngle().normalize().scale(MAX_RANGE));
        BlockHitResult block = level.clip(new ClipContext(origin, last,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 endpoint = block.getType() == HitResult.Type.MISS ? last : block.getLocation();

        LivingEntity closestLiving = null;
        double closestDistanceSqr = origin.distanceToSqr(endpoint);
        AABB area = new AABB(origin, endpoint).inflate(1.5D);
        for (LivingEntity mob : level.getEntitiesOfClass(LivingEntity.class, area,
                e -> e != player && e.isAlive() && !e.isSpectator())) {
            var intersection = mob.getBoundingBox().inflate(0.15D).clip(origin, endpoint);
            if (intersection.isPresent()) {
                double candidate = origin.distanceToSqr(intersection.get());
                if (candidate < closestDistanceSqr) {
                    closestDistanceSqr = candidate;
                    closestLiving = mob;
                }
            }
        }

        if (closestLiving != null) {
            Vec3 aim = closestLiving.position().add(0, closestLiving.getBbHeight() * 0.55D, 0);
            return new Target(aim, closestLiving);
        }
        return new Target(endpoint, null);
    }

    private Targeting() {}
}
