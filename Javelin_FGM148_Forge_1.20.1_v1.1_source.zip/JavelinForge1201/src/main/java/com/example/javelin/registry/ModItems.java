package com.example.javelin.registry;

import com.example.javelin.JavelinMod;
import com.example.javelin.item.JavelinLauncherItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, JavelinMod.MOD_ID);

    public static final RegistryObject<Item> LAUNCHER = ITEMS.register("javelin_launcher",
            () -> new JavelinLauncherItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> ROUND = ITEMS.register("javelin_round",
            () -> new Item(new Item.Properties().stacksTo(16)));

    private ModItems() {}
}
