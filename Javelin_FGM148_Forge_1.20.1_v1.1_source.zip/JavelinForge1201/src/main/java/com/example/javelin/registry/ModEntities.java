package com.example.javelin.registry;

import com.example.javelin.JavelinMod;
import com.example.javelin.entity.JavelinMissileEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, JavelinMod.MOD_ID);

    public static final RegistryObject<EntityType<JavelinMissileEntity>> MISSILE = ENTITIES.register("javelin_missile",
            () -> EntityType.Builder.<JavelinMissileEntity>of(JavelinMissileEntity::new, MobCategory.MISC)
                    .sized(0.45F, 0.45F)
                    .clientTrackingRange(14)
                    .updateInterval(1)
                    .build(JavelinMod.MOD_ID + ":javelin_missile"));

    private ModEntities() {}
}
