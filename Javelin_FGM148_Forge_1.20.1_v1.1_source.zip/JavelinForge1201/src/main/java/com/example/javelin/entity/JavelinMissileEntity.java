package com.example.javelin.entity;

import com.example.javelin.config.JavelinConfig;
import com.example.javelin.gameplay.Targeting;
import com.example.javelin.gameplay.ExplosionEffects;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

import java.util.UUID;

/** Arcade-style guided projectile; not a simulation of real-world missile hardware. */
public class JavelinMissileEntity extends Entity {
    private Vec3 targetPosition = Vec3.ZERO;
    private UUID targetEntityUUID;
    private UUID ownerUUID;
    private boolean exploded;

    public JavelinMissileEntity(EntityType<? extends JavelinMissileEntity> type, Level world) {
        super(type, world);
        this.noPhysics = true;
    }

    public void setLaunch(LivingEntity owner, Targeting.Target target) {
        this.ownerUUID = owner.getUUID();
        this.targetPosition = target.position();
        if (target.living() != null) this.targetEntityUUID = target.living().getUUID();
    }

    @Override
    protected void defineSynchedData() {}

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            // The server also distributes particles for multiplayer clients.
            if (tickCount > 1) {
                Vec3 v = getDeltaMovement();
                level().addParticle(ParticleTypes.FLAME, getX(), getY(), getZ(),
                        -v.x * 0.10D, -v.y * 0.10D, -v.z * 0.10D);
            }
            return;
        }
        if (!(level() instanceof ServerLevel server) || exploded) return;
        if (tickCount > 190 || !level().isInWorldBounds(blockPosition())) {
            impact(server);
            return;
        }

        // The tracked mob can move after launch; its current body position becomes the goal.
        if (targetEntityUUID != null) {
            Entity followed = server.getEntity(targetEntityUUID);
            if (followed instanceof LivingEntity living && living.isAlive()) {
                targetPosition = living.position().add(0, living.getBbHeight() * 0.56D, 0);
            }
        }

        Vec3 before = position();
        Vec3 toTarget = targetPosition.subtract(before);
        double range = toTarget.length();
        if (tickCount > 5 && range < 1.30D) {
            impact(server);
            return;
        }

        // Cinematic top-attack arc followed by steering to the target.
        double speed = Math.min(1.7D, 0.35D + tickCount * 0.030D);
        Vec3 desired = range < 0.001D ? new Vec3(0, 0, 1) : toTarget.normalize();
        if (tickCount < 12 && range > 9.0D) {
            desired = desired.add(0, 0.60D, 0).normalize();
        } else if (tickCount < 25 && range > 28.0D) {
            desired = desired.add(0, 0.24D, 0).normalize();
        }
        Vec3 previous = getDeltaMovement();
        Vec3 motion = previous.lengthSqr() > 0.00001D
                ? previous.normalize().scale(0.50D).add(desired.scale(0.50D)).normalize().scale(speed)
                : desired.scale(speed);
        if (motion.lengthSqr() < 0.00001D) motion = desired.scale(speed);
        setDeltaMovement(motion);
        Vec3 next = before.add(motion);

        // Detect collisions along the movement segment, not just at the final position.
        HitResult blockHit = server.clip(new ClipContext(before, next,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
        if (tickCount > 3 && blockHit.getType() != HitResult.Type.MISS) {
            setPos(blockHit.getLocation().x, blockHit.getLocation().y, blockHit.getLocation().z);
            impact(server);
            return;
        }
        if (tickCount > 7) {
            AABB swept = new AABB(before, next).inflate(0.70D);
            for (LivingEntity living : server.getEntitiesOfClass(LivingEntity.class, swept, LivingEntity::isAlive)) {
                if (ownerUUID != null && ownerUUID.equals(living.getUUID())) continue;
                if (living.getBoundingBox().inflate(0.55D).clip(before, next).isPresent()) {
                    setPos(next.x, next.y, next.z);
                    impact(server);
                    return;
                }
            }
        }
        if (tickCount > 5 && range <= speed + 0.55D) {
            setPos(targetPosition.x, targetPosition.y, targetPosition.z);
            impact(server);
            return;
        }

        setPos(next.x, next.y, next.z);
        setYRot((float) (Mth.atan2(-motion.x, -motion.z) * (180.0D / Math.PI)));
        setXRot((float) (Mth.atan2(motion.y, Math.sqrt(motion.x * motion.x + motion.z * motion.z)) * (180.0D / Math.PI)));
        server.sendParticles(ParticleTypes.SMOKE, before.x, before.y, before.z,
                2, 0.07D, 0.07D, 0.07D, 0.025D);
        server.sendParticles(ParticleTypes.FLAME, before.x, before.y, before.z,
                3, 0.055D, 0.055D, 0.055D, 0.035D);
        if (tickCount % 3 == 0) {
            server.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, before.x, before.y, before.z,
                    1, 0.03D, 0.03D, 0.03D, 0.003D);
        }
    }

    private void impact(ServerLevel server) {
        if (exploded) return;
        exploded = true;
        double x = getX();
        double y = getY();
        double z = getZ();
        Level.ExplosionInteraction behavior = JavelinConfig.BREAK_BLOCKS.get()
                ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.NONE;
        server.explode(this, x, y, z, JavelinConfig.EXPLOSION_POWER.get().floatValue(), behavior);

        ExplosionEffects.spawn(server, new Vec3(x, y, z));
        discard();
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        targetPosition = new Vec3(tag.getDouble("TargetX"), tag.getDouble("TargetY"), tag.getDouble("TargetZ"));
        if (tag.hasUUID("TargetEntity")) targetEntityUUID = tag.getUUID("TargetEntity");
        if (tag.hasUUID("Owner")) ownerUUID = tag.getUUID("Owner");
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putDouble("TargetX", targetPosition.x);
        tag.putDouble("TargetY", targetPosition.y);
        tag.putDouble("TargetZ", targetPosition.z);
        if (targetEntityUUID != null) tag.putUUID("TargetEntity", targetEntityUUID);
        if (ownerUUID != null) tag.putUUID("Owner", ownerUUID);
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
