package com.example.javelin.client;

import com.example.javelin.JavelinMod;
import com.example.javelin.entity.JavelinMissileEntity;
import com.example.javelin.registry.ModItems;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public class MissileRenderer extends EntityRenderer<JavelinMissileEntity> {
    private static final ResourceLocation TEXTURE = JavelinMod.id("textures/item/steel.png");

    public MissileRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.1F;
    }

    @Override
    public void render(JavelinMissileEntity entity, float yaw, float partialTicks, PoseStack pose,
                       MultiBufferSource buffers, int packedLight) {
        pose.pushPose();
        Vec3 v = entity.getDeltaMovement();
        if (v.lengthSqr() < 0.0001D) {
            v = new Vec3(entity.getX() - entity.xo, entity.getY() - entity.yo, entity.getZ() - entity.zo);
        }
        if (v.lengthSqr() > 0.0001D) {
            float rotationY = (float) (Mth.atan2(-v.x, -v.z) * 180.0D / Math.PI);
            float rotationX = (float) (Mth.atan2(v.y, Math.sqrt(v.x * v.x + v.z * v.z)) * 180.0D / Math.PI);
            pose.mulPose(Axis.YP.rotationDegrees(rotationY));
            pose.mulPose(Axis.XP.rotationDegrees(rotationX));
        }
        pose.scale(1.60F, 1.60F, 1.60F);
        Minecraft.getInstance().getItemRenderer().renderStatic(
                new ItemStack(ModItems.ROUND.get()), ItemDisplayContext.NONE,
                packedLight, OverlayTexture.NO_OVERLAY, pose, buffers, entity.level(), entity.getId());
        pose.popPose();
        super.render(entity, yaw, partialTicks, pose, buffers, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(JavelinMissileEntity entity) {
        return TEXTURE;
    }
}
