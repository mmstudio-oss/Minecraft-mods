package com.example.javelin.network;

import com.example.javelin.entity.JavelinMissileEntity;
import com.example.javelin.gameplay.Targeting;
import com.example.javelin.registry.ModEntities;
import com.example.javelin.registry.ModItems;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Carries no targeting info: the authoritative server calculates aiming and ammo. */
public record FireMissilePacket() {
    public static void encode(FireMissilePacket packet, FriendlyByteBuf buf) {}

    public static FireMissilePacket decode(FriendlyByteBuf buf) {
        return new FireMissilePacket();
    }

    public static void handle(FireMissilePacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context ctx = contextSupplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null || !player.isAlive()) return;
            if (!player.isUsingItem() || !player.getUseItem().is(ModItems.LAUNCHER.get())) return;
            if (player.getCooldowns().isOnCooldown(ModItems.LAUNCHER.get())) return;

            int ammoSlot = -1;
            if (!player.getAbilities().instabuild) {
                for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
                    if (player.getInventory().getItem(i).is(ModItems.ROUND.get())) {
                        ammoSlot = i;
                        break;
                    }
                }
                if (ammoSlot < 0) {
                    player.displayClientMessage(Component.translatable("message.javelin.no_ammo"), true);
                    player.getCooldowns().addCooldown(ModItems.LAUNCHER.get(), 15);
                    return;
                }
            }

            Targeting.Target target = Targeting.acquire(player.level(), player);
            Vec3 aim = player.getLookAngle().normalize();
            Vec3 spawn = player.getEyePosition().add(aim.scale(1.05D)).add(0, -0.40D, 0);
            JavelinMissileEntity missile = new JavelinMissileEntity(ModEntities.MISSILE.get(), player.level());
            missile.setPos(spawn.x, spawn.y, spawn.z);
            missile.setLaunch(player, target);
            missile.setDeltaMovement(aim.scale(0.34D).add(0, 0.14D, 0));
            player.level().addFreshEntity(missile);
            player.level().playSound(null, player.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH,
                    SoundSource.PLAYERS, 2.0F, 0.66F);
            if (ammoSlot >= 0) {
                ItemStack stack = player.getInventory().getItem(ammoSlot);
                stack.shrink(1);
                player.getInventory().setChanged();
            }
            player.getCooldowns().addCooldown(ModItems.LAUNCHER.get(), 45);
        });
        ctx.setPacketHandled(true);
    }
}
