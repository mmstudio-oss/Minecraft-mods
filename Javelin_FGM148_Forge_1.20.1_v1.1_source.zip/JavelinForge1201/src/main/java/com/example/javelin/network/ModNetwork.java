package com.example.javelin.network;

import com.example.javelin.JavelinMod;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.ChannelBuilder
            .named(JavelinMod.id("main"))
            .networkProtocolVersion(() -> PROTOCOL)
            .clientAcceptedVersions(PROTOCOL::equals)
            .serverAcceptedVersions(PROTOCOL::equals)
            .simpleChannel();

    public static void init() {
        CHANNEL.registerMessage(0, FireMissilePacket.class,
                FireMissilePacket::encode, FireMissilePacket::decode, FireMissilePacket::handle);
    }

    private ModNetwork() {}
}
