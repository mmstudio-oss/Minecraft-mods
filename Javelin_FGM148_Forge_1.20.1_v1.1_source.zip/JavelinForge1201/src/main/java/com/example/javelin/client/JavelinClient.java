package com.example.javelin.client;

import com.example.javelin.JavelinMod;
import com.example.javelin.gameplay.Targeting;
import com.example.javelin.network.FireMissilePacket;
import com.example.javelin.network.ModNetwork;
import com.example.javelin.registry.ModEntities;
import com.example.javelin.registry.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public final class JavelinClient {
    private static final int CHARGE_TICKS = 12;
    private static int heldAttackTicks = 0;
    private static boolean firedInThisHold = false;

    @Mod.EventBusSubscriber(modid = JavelinMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class Registration {
        @SubscribeEvent
        public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
            event.registerEntityRenderer(ModEntities.MISSILE.get(), MissileRenderer::new);
        }
    }

    @Mod.EventBusSubscriber(modid = JavelinMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static class Events {
        private static boolean isAiming() {
            Minecraft mc = Minecraft.getInstance();
            return mc.player != null && mc.player.isUsingItem()
                    && mc.player.getUseItem().is(ModItems.LAUNCHER.get());
        }

        @SubscribeEvent
        public static void preventVanillaAttack(InputEvent.InteractionKeyMappingTriggered event) {
            if (event.isAttack() && isAiming()) {
                event.setCanceled(true);
                event.setSwingHand(false);
            }
        }

        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.screen != null || !isAiming()) {
                heldAttackTicks = 0;
                firedInThisHold = false;
                return;
            }
            if (!mc.options.keyAttack.isDown()) {
                heldAttackTicks = 0;
                firedInThisHold = false;
                return;
            }
            if (firedInThisHold) return;
            if (mc.player.getCooldowns().isOnCooldown(ModItems.LAUNCHER.get())) return;
            heldAttackTicks++;
            if (heldAttackTicks >= CHARGE_TICKS) {
                ModNetwork.CHANNEL.sendToServer(new FireMissilePacket());
                firedInThisHold = true;
            }
        }

        @SubscribeEvent
        public static void onZoom(ViewportEvent.ComputeFov event) {
            if (isAiming()) event.setFOV(event.getFOV() * 0.35D);
        }

        @SubscribeEvent
        public static void onRenderHud(RenderGuiEvent.Post event) {
            if (!isAiming()) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) return;
            GuiGraphics g = event.getGuiGraphics();
            int w = event.getWindow().getGuiScaledWidth();
            int h = event.getWindow().getGuiScaledHeight();
            int cx = w / 2;
            int cy = h / 2;
            int r = Math.max(52, Math.min(w, h) / 4);
            int green = 0xFF8EEA72;
            int gold = 0xFFECC577;

            // Pixel-styled CLU scope: shaded outside, reticle, calibration bars.
            g.fill(0, 0, w, Math.max(0, cy - r - 8), 0xC9000709);
            g.fill(0, cy + r + 8, w, h, 0xC9000709);
            g.fill(0, cy - r - 8, Math.max(0, cx - r - 8), cy + r + 8, 0xC9000709);
            g.fill(cx + r + 8, cy - r - 8, w, cy + r + 8, 0xC9000709);
            g.fill(cx - r, cy - r, cx + r, cy - r + 2, green);
            g.fill(cx - r, cy + r - 2, cx + r, cy + r, green);
            g.fill(cx - r, cy - r, cx - r + 2, cy + r, green);
            g.fill(cx + r - 2, cy - r, cx + r, cy + r, green);
            // Segmented circular outline feels at home with Minecraft's pixel aesthetic.
            for (int i = 0; i < 64; i++) {
                double a = (i / 64.0D) * Math.PI * 2.0D;
                int x = cx + (int) (Math.cos(a) * (r - 8));
                int y = cy + (int) (Math.sin(a) * (r - 8));
                if ((i % 4) != 0) g.fill(x, y, x + 2, y + 2, 0xAA8EEA72);
            }
            g.fill(cx - 20, cy, cx - 5, cy + 1, green);
            g.fill(cx + 6, cy, cx + 21, cy + 1, green);
            g.fill(cx, cy - 20, cx + 1, cy - 5, green);
            g.fill(cx, cy + 6, cx + 1, cy + 21, green);
            g.fill(cx - 2, cy - 2, cx + 3, cy + 3, gold);

            Targeting.Target aim = Targeting.acquire(mc.level, mc.player);
            int distance = (int) mc.player.getEyePosition().distanceTo(aim.position());
            String targetType = Component.translatable(aim.hasEntity()
                    ? "hud.javelin.entity" : "hud.javelin.terrain").getString();
            String status;
            if (mc.player.getCooldowns().isOnCooldown(ModItems.LAUNCHER.get())) {
                status = Component.translatable("hud.javelin.reloading").getString();
            } else if (firedInThisHold) {
                status = Component.translatable("hud.javelin.fired").getString();
            } else if (heldAttackTicks > 0) {
                status = Component.translatable("hud.javelin.locking", heldAttackTicks * 100 / CHARGE_TICKS).getString();
            } else {
                status = Component.translatable("hud.javelin.ready").getString();
            }
            g.drawString(mc.font, "JAVELIN | CLU", cx - r + 12, cy - r + 10, green, true);
            g.drawString(mc.font, targetType + "  " + distance + "m", cx - r + 12, cy + r - 24, green, true);
            g.drawString(mc.font, status, cx - r + 12, cy + r - 12, gold, true);
            if (heldAttackTicks > 0 && !firedInThisHold) {
                int size = (r * 2 - 24) * Math.min(heldAttackTicks, CHARGE_TICKS) / CHARGE_TICKS;
                g.fill(cx - r + 12, cy + r - 31, cx - r + 12 + size, cy + r - 28, gold);
            }
        }
    }

    private JavelinClient() {}
}
