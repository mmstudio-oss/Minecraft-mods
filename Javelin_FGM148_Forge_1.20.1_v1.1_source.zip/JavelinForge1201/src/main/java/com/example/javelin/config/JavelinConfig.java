package com.example.javelin.config;

import net.minecraftforge.common.ForgeConfigSpec;

public final class JavelinConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue BREAK_BLOCKS;
    public static final ForgeConfigSpec.DoubleValue EXPLOSION_POWER;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.push("javelin");
        BREAK_BLOCKS = builder.comment("Whether explosions can break terrain. Disabled by default to protect builds.")
                .define("breakBlocks", false);
        EXPLOSION_POWER = builder.comment("Explosion strength: 2.0 to 8.0.")
                .defineInRange("explosionPower", 4.0D, 2.0D, 8.0D);
        builder.pop();
        SPEC = builder.build();
    }

    private JavelinConfig() {}
}
