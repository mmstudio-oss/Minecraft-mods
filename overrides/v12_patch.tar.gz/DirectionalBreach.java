package com.example.javelin.gameplay;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Set;

/**
 * Minecraft-gameplay-oriented impact: a ~2x2 block cross-section driven up to
 * five blocks into the world along the last flight vector. A tiny safe fixed
 * budget and unbreakable/container checks prevent runaway block destruction.
 * This is an arcade effect, not a model of any real weapon's terminal effects.
 */
public final class DirectionalBreach {
    private static final int DEPTH_BLOCKS = 5;
    private static final double[] OFFSETS = {-0.55D, 0.55D};

    public static void carve(ServerLevel level, Vec3 impact, Vec3 flight) {
        if (flight.lengthSqr() < 1.0E-5D) return;
        Vec3 forward = flight.normalize();
        Vec3 reference = Math.abs(forward.y) < 0.9D ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0);
        Vec3 sideways = forward.cross(reference).normalize();
        Vec3 upwards = sideways.cross(forward).normalize();

        // Visit each block once (oblique impacts can cause cells to overlap).
        Set<BlockPos> visited = new HashSet<>();
        for (int depth = 0; depth < DEPTH_BLOCKS; depth++) {
            Vec3 center = impact.add(forward.scale(0.60D + depth));
            for (double side : OFFSETS) {
                for (double up : OFFSETS) {
                    Vec3 sample = center.add(sideways.scale(side)).add(upwards.scale(up));
                    BlockPos pos = BlockPos.containing(sample);
                    if (!visited.add(pos) || !level.isInWorldBounds(pos) || !level.isLoaded(pos)) continue;
                    BlockState state = level.getBlockState(pos);
                    if (state.isAir() || state.hasBlockEntity() || state.getDestroySpeed(level, pos) < 0) continue;
                    if (level.destroyBlock(pos, false)) {
                        level.sendParticles(ParticleTypes.CLOUD, pos.getX() + 0.5D,
                                pos.getY() + 0.5D, pos.getZ() + 0.5D,
                                3, 0.22D, 0.22D, 0.22D, 0.02D);
                    }
                }
            }
        }
    }
    private DirectionalBreach() {}
}
