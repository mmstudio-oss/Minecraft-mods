"""Apply the 1.2 Minecraft-style visual and directed terrain-impact update to the 1.1 source."""
from pathlib import Path
import json
import shutil

root = Path(__file__).resolve().parents[1] / 'JavelinForge1201'
assets = root / 'src/main/resources/assets/javelin/models/item'
faces = ('north', 'south', 'east', 'west', 'up', 'down')
textures = ('olive','olive_light','olive_dark','black','rubber','steel','steel_dark','gold','copper','warhead','optic')

def cube(a,b,tex):
    return {'from':list(a),'to':list(b),'faces':{side:{'texture':'#'+tex} for side in faces}}

# Main 16px axis is Z: a segmented green shoulder tube and charcoal front
# aperture/CLU/grips like the pixel-model reference image.
launcher = [
  # Slightly tapered olive barrel: faceted/stepped cubic Minecraft silhouette.
  cube((5.1,10.1,2.0),(10.9,15.5,14.8),'olive_dark'),
  cube((5.4,10.3,2.6),(10.6,15.2,14.5),'olive'),
  cube((5.0,10.0,2.5),(11.0,15.5,3.2),'olive_light'),
  cube((5.0,10.0,5.0),(11.0,15.5,5.65),'olive_light'),
  cube((5.0,10.0,7.55),(11.0,15.5,8.2),'olive_light'),
  cube((5.0,10.0,10.15),(11.0,15.5,10.8),'olive_light'),
  cube((5.0,10.0,12.75),(11.0,15.5,13.4),'olive_dark'),
  # Blocky black muzzle opening and two depth layers (front at Z negative).
  cube((3.8,8.9,-0.7),(12.2,16.6,2.15),'black'),
  cube((4.5,9.5,-1.0),(11.5,16.0,0.05),'rubber'),
  cube((5.15,10.1,-1.15),(10.85,15.4,-1.0),'warhead'),
  cube((6.0,10.8,-1.22),(10.0,14.65,-1.10),'black'),
  cube((4.0,9.1,1.65),(12.0,16.4,2.15),'rubber'),
  # Short dark shoulder-side rear cap.
  cube((4.8,9.8,14.6),(11.2,15.75,15.8),'black'),
  cube((4.0,9.0,15.6),(12.0,16.6,16.8),'black'),
  cube((4.7,9.55,16.8),(11.3,16.15,17.15),'rubber'),
  # Faint mustard connector line before the rear cap.
  cube((4.9,10.0,14.30),(11.1,15.65,14.75),'gold'),
  # Squared side-mounted sight box with faceted dark rims.
  cube((10.5,7.1,3.2),(14.75,12.5,9.7),'black'),
  cube((11.0,8.1,2.7),(15.2,11.95,5.3),'rubber'),
  cube((11.6,8.55,2.55),(14.45,11.3,2.75),'steel_dark'),
  cube((12.1,9.0,2.48),(14.0,10.9,2.56),'optic'),
  cube((12.7,10.1,5.9),(15.45,13.0,9.2),'black'),
  cube((13.2,10.5,6.2),(15.55,12.55,8.9),'rubber'),
  cube((15.47,11.1,6.8),(15.65,12.1,8.25),'optic'),
  cube((11.15,6.85,7.3),(14.5,7.35,10.6),'steel_dark'),
  # Underbody electronics and compact angled-grip silhouette.
  cube((6.3,8.15,4.7),(11.8,10.4,11.3),'black'),
  cube((7.2,5.4,6.4),(10.1,8.8,9.25),'rubber'),
  cube((7.0,3.45,6.7),(9.1,6.05,8.75),'black'),
  cube((8.35,2.6,7.7),(10.35,4.2,9.35),'black'),
  cube((6.4,7.85,9.3),(9.25,8.95,12.0),'steel_dark'),
  cube((6.9,6.55,10.9),(8.95,8.35,12.55),'black'),
  # A few subtle dark barrel seam plates, visually reinforcing the ribbing.
  cube((5.6,15.15,4.1),(10.4,15.64,4.45),'olive_dark'),
  cube((5.6,15.15,9.3),(10.4,15.64,9.65),'olive_dark'),
]

# Long thin 24px missile, roughly 8:1 body aspect ratio. Finlets are blocky.
rocket = [
  cube((7.25,7.25,-4.0),(8.75,8.75,-2.8),'warhead'),
  cube((6.8,6.8,-2.8),(9.2,9.2,-1.4),'warhead'),
  cube((6.5,6.5,-1.45),(9.5,9.5,16.5),'steel'),
  cube((6.35,6.35,-1.4),(9.65,9.65,-0.95),'copper'),
  cube((6.42,6.42,3.5),(9.58,9.58,4.15),'black'),
  cube((6.42,6.42,11.0),(9.58,9.58,11.55),'steel_dark'),
  cube((6.35,6.35,16.25),(9.65,9.65,20.0),'black'),
  cube((6.8,6.8,19.7),(9.2,9.2,20.3),'steel_dark'),
  # Guidance stabilizers and smaller front tabs.
  cube((4.45,7.48,16.25),(6.6,8.52,19.15),'warhead'),
  cube((9.4,7.48,16.25),(11.55,8.52,19.15),'warhead'),
  cube((7.48,4.45,16.25),(8.52,6.6,19.15),'warhead'),
  cube((7.48,9.4,16.25),(8.52,11.55,19.15),'warhead'),
  cube((5.45,7.65,11.25),(6.55,8.35,13.0),'steel_dark'),
  cube((9.45,7.65,11.25),(10.55,8.35,13.0),'steel_dark'),
  cube((7.65,5.45,11.25),(8.35,6.55,13.0),'steel_dark'),
  cube((7.65,9.45,11.25),(8.35,10.55,13.0),'steel_dark'),
]

def model(name, elements, display):
    data={'credit':'Minecraft-style Javelin v1.2 original pixel model',
          'texture_size':[16,16],
          'textures':{t:'javelin:item/'+t for t in textures},
          'elements':elements,'display':display}
    (assets/(name+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')

model('javelin_launcher',launcher,{
 'gui':{'rotation':[24,42,0],'translation':[0,0,0],'scale':[.90,.90,.90]},
 'ground':{'rotation':[0,0,0],'translation':[0,3,0],'scale':[.68,.68,.68]},
 'fixed':{'rotation':[0,180,0],'translation':[0,0,0],'scale':[.76,.76,.76]},
 'thirdperson_righthand':{'rotation':[3,-80,68],'translation':[0,3,-1],'scale':[1.35,1.35,1.35]},
 'thirdperson_lefthand':{'rotation':[3,80,-68],'translation':[0,3,-1],'scale':[1.35,1.35,1.35]},
 'firstperson_righthand':{'rotation':[3,-95,37],'translation':[2,2,1],'scale':[1.7,1.7,1.7]},
 'firstperson_lefthand':{'rotation':[3,95,-37],'translation':[-2,2,1],'scale':[1.7,1.7,1.7]},
})
model('javelin_round',rocket,{
 'gui':{'rotation':[20,140,10],'translation':[0,0,0],'scale':[.7,.7,.7]},
 'ground':{'rotation':[0,0,0],'translation':[0,2,0],'scale':[.6,.6,.6]},
 'fixed':{'rotation':[0,0,0],'translation':[0,0,0],'scale':[.72,.72,.72]},
 'firstperson_righthand':{'rotation':[0,65,0],'translation':[0,2,0],'scale':[.65,.65,.65]},
 'thirdperson_righthand':{'rotation':[0,65,0],'translation':[0,2,0],'scale':[.7,.7,.7]},
})

# Controlled 2x2 cross-section x 5-block-long oriented destruction volume.
shutil.copy2(Path(__file__).parent/'DirectionalBreach.java',
             root/'src/main/java/com/example/javelin/gameplay/DirectionalBreach.java')
entity_file = root/'src/main/java/com/example/javelin/entity/JavelinMissileEntity.java'
old=entity_file.read_text(encoding='utf-8')
assert 'Level.ExplosionInteraction behavior = JavelinConfig.BREAK_BLOCKS.get()' in old
old=old.replace('import com.example.javelin.gameplay.ExplosionEffects;',
                'import com.example.javelin.gameplay.ExplosionEffects;\nimport com.example.javelin.gameplay.DirectionalBreach;')
old=old.replace('''        Level.ExplosionInteraction behavior = JavelinConfig.BREAK_BLOCKS.get()
                ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.NONE;
        server.explode(this, x, y, z, JavelinConfig.EXPLOSION_POWER.get().floatValue(), behavior);

        ExplosionEffects.spawn(server, new Vec3(x, y, z));''', '''        // Vanilla handles damage/sound only, avoiding a random wide TNT crater.
        server.explode(this, x, y, z, JavelinConfig.EXPLOSION_POWER.get().floatValue(),
                Level.ExplosionInteraction.NONE);
        if (JavelinConfig.BREAK_BLOCKS.get()) {
            DirectionalBreach.carve(server, new Vec3(x, y, z), getDeltaMovement());
        }
        ExplosionEffects.spawn(server, new Vec3(x, y, z));''')
assert 'DirectionalBreach.carve' in old
entity_file.write_text(old,encoding='utf-8')

cfg=root/'src/main/java/com/example/javelin/config/JavelinConfig.java'
text=cfg.read_text(encoding='utf-8').replace(
 'Whether explosions can break terrain. Disabled by default to protect builds.',
 'Make a directional 2x2 by 5 block impact crater (default: true).')
assert '.define("breakBlocks", false)' in text
cfg.write_text(text.replace('.define("breakBlocks", false)', '.define("breakBlocks", true)'),encoding='utf-8')

props=root/'gradle.properties'
p=props.read_text(encoding='utf-8')
assert 'mod_version=1.1.0' in p
props.write_text(p.replace('mod_version=1.1.0','mod_version=1.2.0'),encoding='utf-8')
mods=root/'src/main/resources/META-INF/mods.toml'
t=mods.read_text(encoding='utf-8')
assert 'version="1.1.0"' in t
mods.write_text(t.replace('version="1.1.0"','version="1.2.0"'),encoding='utf-8')
print('Applied Javelin 1.2: launcher model',len(launcher),'cubes, missile model',len(rocket),'cubes, directional block impact')
